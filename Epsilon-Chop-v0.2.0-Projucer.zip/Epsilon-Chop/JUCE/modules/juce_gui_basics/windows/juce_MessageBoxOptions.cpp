/*
  ==============================================================================

   This file is part of the JUCE framework.
   Copyright (c) Raw Material Software Limited

   JUCE is an open source framework subject to commercial or open source
   licensing.

   By downloading, installing, or using the JUCE framework, or combining the
   JUCE framework with any other source code, object code, content or any other
   copyrightable work, you agree to the terms of the JUCE End User Licence
   Agreement, and all incorporated terms including the JUCE Privacy Policy and
   the JUCE Website Terms of Service, as applicable, which will bind you. If you
   do not agree to the terms of these agreements, we will not license the JUCE
   framework to you, and you must discontinue the installation or download
   process and cease use of the JUCE framework.

   JUCE End User Licence Agreement: https://juce.com/legal/juce-9-licence/
   JUCE Privacy Policy: https://juce.com/juce-privacy-policy
   JUCE Website Terms of Service: https://juce.com/juce-website-terms-of-service/

   Or:

   You may also use this code under the terms of the AGPLv3:
   https://www.gnu.org/licenses/agpl-3.0.en.html

   THE JUCE FRAMEWORK IS PROVIDED "AS IS" WITHOUT ANY WARRANTY, AND ALL
   WARRANTIES, WHETHER EXPRESSED OR IMPLIED, INCLUDING WARRANTY OF
   MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, ARE DISCLAIMED.

  ==============================================================================
*/

namespace juce
{

MessageBoxOptions MessageBoxOptions::withButton (MessageBoxButtonOptions opt) const
{
    auto copy = *this;
    copy.buttons.push_back (std::move (opt));

    // Only a maximum of one action may be preferred!
    // Check your MessageBoxOptions and make sure that you haven't called
    // "setPreferredAction (true)" more than once.
    jassert (std::count_if (copy.buttons.begin(),
                            copy.buttons.end(),
                            [] (const auto& b) { return b.isPreferredAction(); }) <= 1);

    // Only a maximum of one action may have the cancel role!
    // Check your MessageBoxOptions and make sure that you haven't called
    // "setRole (MessageBoxButtonRole::cancel)" more than once.
    jassert (std::count_if (copy.buttons.begin(),
                            copy.buttons.end(),
                            [] (const auto& b) { return b.getRole() == MessageBoxButtonRole::cancel; }) <= 1);

    return copy;
}

MessageBoxOptions MessageBoxOptions::makeOptionsOk (MessageBoxIconType iconType,
                                                    const String& title,
                                                    const String& message,
                                                    const String& buttonText,
                                                    Component* associatedComponent)
{
    return MessageBoxOptions()
        .withIconType (iconType)
        .withTitle (title)
        .withMessage (message)
        .withButton (MessageBoxButtonOptions { buttonText.isEmpty() ? TRANS ("OK") : buttonText, 0 }.setPreferredAction()
                                                                                                    .setRole (MessageBoxButtonRole::cancel))
        .withAssociatedComponent (associatedComponent);
}

MessageBoxOptions MessageBoxOptions::makeOptionsOkCancel (MessageBoxIconType iconType,
                                                          const String& title,
                                                          const String& message,
                                                          const String& button1Text,
                                                          const String& button2Text,
                                                          Component* associatedComponent)
{
    return MessageBoxOptions()
        .withIconType (iconType)
        .withTitle (title)
        .withMessage (message)
        .withButton (MessageBoxButtonOptions { button1Text.isEmpty() ? TRANS ("OK") : button1Text, 1 }.setPreferredAction())
        .withButton (MessageBoxButtonOptions { button2Text.isEmpty() ? TRANS ("Cancel") : button2Text, 0 }.setRole (MessageBoxButtonRole::cancel))
        .withAssociatedComponent (associatedComponent);
}

MessageBoxOptions MessageBoxOptions::makeOptionsYesNo (MessageBoxIconType iconType,
                                                       const String& title,
                                                       const String& message,
                                                       const String& button1Text,
                                                       const String& button2Text,
                                                       Component* associatedComponent)
{
    return MessageBoxOptions()
        .withIconType (iconType)
        .withTitle (title)
        .withMessage (message)
        .withButton (button1Text.isEmpty() ? TRANS ("Yes") : button1Text, 1)
        .withButton (button2Text.isEmpty() ? TRANS ("No") : button2Text, 0)
        .withAssociatedComponent (associatedComponent);
}

MessageBoxOptions MessageBoxOptions::makeOptionsYesNoCancel (MessageBoxIconType iconType,
                                                             const String& title,
                                                             const String& message,
                                                             const String& button1Text,
                                                             const String& button2Text,
                                                             const String& button3Text,
                                                             Component* associatedComponent)
{
    return MessageBoxOptions()
        .withIconType (iconType)
        .withTitle (title)
        .withMessage (message)
        .withButton (button1Text.isEmpty() ? TRANS ("Yes") : button1Text, 1)
        .withButton (button2Text.isEmpty() ? TRANS ("No") : button2Text, 2)
        .withButton (MessageBoxButtonOptions { button3Text.isEmpty() ? TRANS ("Cancel") : button3Text, 0 }.setRole (MessageBoxButtonRole::cancel))
        .withAssociatedComponent (associatedComponent);
}

} // namespace juce
