#pragma once

#include "PluginProcessor.h"

class EpsilonChopEditor final : public juce::AudioProcessorEditor,
                               public juce::FileDragAndDropTarget,
                               private juce::Timer
{
public:
    explicit EpsilonChopEditor(EpsilonChopProcessor&);
    ~EpsilonChopEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;
    void mouseDown(const juce::MouseEvent&) override;
    void mouseDoubleClick(const juce::MouseEvent&) override;
    void mouseDrag(const juce::MouseEvent&) override;
    void mouseUp(const juce::MouseEvent&) override;
    bool isInterestedInFileDrag(const juce::StringArray&) override;
    void fileDragEnter(const juce::StringArray&, int, int) override;
    void fileDragExit(const juce::StringArray&) override;
    void filesDropped(const juce::StringArray&, int, int) override;

private:
    void timerCallback() override;
    void refresh();
    void syncStepControls();
    void chooseSample();
    void setGateFromControl();
    void paintWaveform(juce::Graphics&) const;
    void paintSteps(juce::Graphics&) const;
    juce::Rectangle<int> waveformBody() const;
    juce::Rectangle<int> stepBounds(int index) const;
    int frameAt(int x) const;
    int markerNear(int x) const;
    int displaySlice(int slice) const;

    EpsilonChopProcessor& processor;
    juce::LookAndFeel_V4 look;
    EpsilonChopProcessor::EditorState view;
    juce::TextButton load { "Load Sample" }, stop { "Stop Preview" };
    juce::TextButton run { "Play Pattern" }, random { "Random" }, move { "Move & Trim" }, undo { "Undo" };
    std::array<juce::TextButton, chop::bankCount> banks;
    juce::ComboBox mode, density, preset, stepSlice;
    juce::Slider output, gate;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> outputAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> runAttachment;
    std::unique_ptr<juce::FileChooser> chooser;
    juce::Rectangle<int> waveArea, stepArea, actionsArea;
    int selectedStep = 0, selectedChop = 0;
    int dragMarker = -1, dragFrame = 0, displayedSliceCount = -1;
    std::uint64_t dragRevision = 0;
    bool draggingFile = false, draggingGate = false;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(EpsilonChopEditor)
};
