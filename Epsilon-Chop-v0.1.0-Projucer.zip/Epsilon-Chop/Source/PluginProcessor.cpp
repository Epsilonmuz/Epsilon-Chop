#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "SampleAnalysis.h"

#include <algorithm>
#include <cmath>

namespace
{
constexpr int stateMagic = 0x50484345;
constexpr int stateVersion = 1;
constexpr int historyLimit = 24;
constexpr int maximumNameBytes = 1024;

juce::AudioProcessorValueTreeState::ParameterLayout parameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    layout.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID { "pattern", 1 }, "Pattern", false));
    const auto db = juce::AudioParameterFloatAttributes {}.withLabel("dB");
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID { "output", 1 }, "Output",
               juce::NormalisableRange<float> { -24.0f, 6.0f, 0.1f }, -3.0f, db));
    return layout;
}

int markerSpacing(const chop::Sample& sample)
{
    return std::max(1, juce::roundToInt(sample.sampleRate * 0.004));
}

float safeAudio(float value) noexcept
{
    return std::isfinite(value) ? juce::jlimit(-8.0f, 8.0f, value) : 0.0f;
}

void writeEdit(juce::MemoryOutputStream& out, const chop::Edit& edit)
{
    out.writeInt(static_cast<int>(edit.mode));
    out.writeInt(edit.density);
    out.writeInt(edit.bank);
    out.writeInt(edit.manual.count);
    for (int index = 0; index <= edit.manual.count; ++index)
        out.writeInt(edit.manual.edge[index]);
    for (const auto& bank : edit.patterns)
        for (const auto& step : bank)
        {
            out.writeInt(step.slice);
            out.writeInt(step.gate);
        }
}

bool readEdit(juce::MemoryInputStream& input, chop::Edit& edit)
{
    const auto mode = input.readInt();
    edit.density = input.readInt();
    edit.bank = input.readInt();
    edit.manual.count = input.readInt();
    if (mode < 0 || mode > 2 || edit.density < 1 || edit.density > chop::maxSlices
        || edit.bank < 0 || edit.bank >= chop::bankCount
        || edit.manual.count < 0 || edit.manual.count > chop::maxSlices)
        return false;
    const auto minimumBytes = 4 * (edit.manual.count + 1 + 2 * chop::bankCount * chop::stepCount + 1);
    if (input.getNumBytesRemaining() < minimumBytes)
        return false;

    edit.mode = static_cast<chop::SliceMode>(mode);
    for (int index = 0; index <= edit.manual.count; ++index)
        edit.manual.edge[index] = input.readInt();
    for (auto& bank : edit.patterns)
        for (auto& step : bank)
        {
            step.slice = input.readInt();
            step.gate = input.readInt();
            if (step.slice < -1 || step.slice >= chop::maxSlices || step.gate < 10 || step.gate > 100)
                return false;
        }
    return true;
}

void writeSample(juce::MemoryOutputStream& out, const chop::Sample* sample)
{
    out.writeInt(sample == nullptr ? 0 : sample->channels);
    if (sample == nullptr)
        return;

    out.writeDouble(sample->sampleRate);
    out.writeInt(sample->length());
    const auto nameSize = static_cast<int>(std::min<std::size_t>(maximumNameBytes, sample->name.size()));
    out.writeInt(nameSize);
    out.write(sample->name.data(), static_cast<std::size_t>(nameSize));
    out.writeInt(sample->transientCount);
    for (int index = 0; index < sample->transientCount; ++index)
        out.writeInt(sample->transients[index]);
    for (int channel = 0; channel < sample->channels; ++channel)
    {
       #if JUCE_BIG_ENDIAN
        for (const auto value : sample->pcm[channel])
            out.writeFloat(value);
       #else
        out.write(sample->pcm[channel].data(), sample->pcm[channel].size() * sizeof(float));
       #endif
    }
}

bool readSample(juce::MemoryInputStream& input, std::shared_ptr<const chop::Sample>& destination)
{
    const auto channels = input.readInt();
    if (channels == 0)
        return input.getNumBytesRemaining() == 0;
    if (input.getNumBytesRemaining() < 20)
        return false;
    const auto rate = input.readDouble();
    const auto frames = input.readInt();
    const auto nameSize = input.readInt();
    if (!chop::validSampleSize(rate, channels, frames) || nameSize < 0 || nameSize > maximumNameBytes
        || input.getNumBytesRemaining() < nameSize + 4)
        return false;

    auto sample = std::make_shared<chop::Sample>();
    sample->channels = channels;
    sample->sampleRate = rate;
    sample->name.resize(static_cast<std::size_t>(nameSize));
    if (input.read(sample->name.data(), nameSize) != nameSize)
        return false;

    sample->transientCount = input.readInt();
    const auto bytesPerChannel = frames * static_cast<int>(sizeof(float));
    if (sample->transientCount < 0 || sample->transientCount >= chop::maxSlices
        || input.getNumBytesRemaining() != 4 * sample->transientCount + channels * bytesPerChannel)
        return false;

    for (int index = 0; index < sample->transientCount; ++index)
    {
        const auto marker = input.readInt();
        if (marker <= 0 || marker >= frames
            || std::find(sample->transients.begin(), sample->transients.begin() + index, marker)
               != sample->transients.begin() + index)
            return false;
        sample->transients[index] = marker;
    }
    for (int channel = 0; channel < channels; ++channel)
    {
        auto& data = sample->pcm[channel];
        data.resize(static_cast<std::size_t>(frames));
       #if JUCE_BIG_ENDIAN
        for (auto& value : data)
            value = input.readFloat();
       #else
        if (input.read(data.data(), bytesPerChannel) != bytesPerChannel)
            return false;
       #endif
        for (auto& value : data)
            value = safeAudio(value);
    }
    chop::buildWaveform(*sample);
    destination = std::move(sample);
    return true;
}
}

EpsilonChopProcessor::EpsilonChopProcessor()
    : AudioProcessor(BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "EpsilonChopParameters", parameterLayout())
{
    outputParameter = parameters.getRawParameterValue("output");
    patternParameter = parameters.getRawParameterValue("pattern");
    history.reserve(historyLimit);
    auto initial = std::make_unique<chop::Session>();
    initial->edit = chop::defaultEdit();
    publishLocked(std::move(initial));
}

EpsilonChopProcessor::~EpsilonChopProcessor()
{
    loadSerial.fetch_add(1);
    loader.removeAllJobs(true, -1);
}

bool EpsilonChopProcessor::isBusesLayoutSupported(const BusesLayout& layout) const
{
    const auto out = layout.getMainOutputChannelSet();
    return out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo();
}

void EpsilonChopProcessor::prepareToPlay(double sampleRate, int)
{
    engine.prepare(sampleRate, juce::Decibels::decibelsToGain(outputParameter->load()));
}

void EpsilonChopProcessor::releaseResources()
{
    engine.reset();
    currentStep.store(-1);
    currentFrame.store(-1);
}

const chop::Session* EpsilonChopProcessor::acquireAudioState() noexcept
{
    // Publish the hazard before validating the pointer. Retired generations
    // are freed only on the editor, state, or loader threads.
    for (int attempt = 0; attempt < 3; ++attempt)
    {
        const auto* candidate = published.load();
        audioHazard.store(candidate);
        const auto* confirmed = published.load();
        if (candidate == confirmed)
            return confirmed;
    }
    audioHazard.store(nullptr);
    return nullptr;
}

void EpsilonChopProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    const auto frames = buffer.getNumSamples();
    buffer.clear();
    if (frames == 0 || buffer.getNumChannels() == 0)
    {
        midi.clear();
        return;
    }

    const auto* current = acquireAudioState();
    if (current == nullptr)
    {
        midi.clear();
        return;
    }

    chop::Transport transport;
    if (auto* playhead = getPlayHead())
        if (auto position = playhead->getPosition())
            if (auto bpm = position->getBpm())
                if (auto ppq = position->getPpqPosition())
                    transport = { *ppq, *bpm, position->getIsPlaying() };

    engine.beginBlock(*current, transport, patternParameter->load(std::memory_order_relaxed) >= 0.5f,
                      frames, juce::Decibels::decibelsToGain(outputParameter->load(std::memory_order_relaxed)));

    const auto request = previewRequest.exchange(-1, std::memory_order_relaxed);
    if (request == -2)
        engine.stop(chop::VoiceOrigin::preview);
    else if (request >= 0)
        engine.trigger(request, 1.0f, chop::VoiceOrigin::preview);

    auto* left = buffer.getWritePointer(0);
    auto* right = buffer.getNumChannels() > 1 ? buffer.getWritePointer(1) : nullptr;
    auto event = midi.begin();
    const auto end = midi.end();
    for (int frame = 0; frame < frames; ++frame)
    {
        while (event != end && (*event).samplePosition <= frame)
        {
            const auto message = *event++;
            if (message.numBytes < 3)
                continue;
            const auto statusByte = message.data[0] & 0xf0;
            if (statusByte == 0x90 && message.data[2] != 0)
                engine.trigger(static_cast<int>(message.data[1]) - chop::firstMidiNote,
                               message.data[2] / 127.0f, chop::VoiceOrigin::midi);
            else if (statusByte == 0xb0 && (message.data[1] == 120 || message.data[1] == 123))
                engine.stop(chop::VoiceOrigin::midi);
        }
        float l = 0.0f, r = 0.0f;
        engine.render(frame, l, r);
        left[frame] = right != nullptr ? l : (l + r) * 0.5f;
        if (right != nullptr)
            right[frame] = r;
    }
    midi.clear();
    currentStep.store(engine.currentStep(), std::memory_order_relaxed);
    currentFrame.store(engine.currentFrame(), std::memory_order_relaxed);
    engine.endBlock();
    audioHazard.store(nullptr);
}

void EpsilonChopProcessor::reclaimLocked()
{
    const auto* current = published.load();
    const auto* active = audioHazard.load();
    snapshots.erase(std::remove_if(snapshots.begin(), snapshots.end(), [current, active](const auto& item)
    {
        return item.get() != current && item.get() != active;
    }), snapshots.end());
}

void EpsilonChopProcessor::publishLocked(std::unique_ptr<chop::Session> session)
{
    session->revision = ++revision;
    session->slices = session->sample != nullptr ? chop::makeSlices(*session->sample, session->edit) : chop::Slices {};
    auto* next = session.get();
    snapshots.push_back(std::move(session));
    published.store(next);
    reclaimLocked();
}

EpsilonChopProcessor::EditorState EpsilonChopProcessor::editorState() const
{
    const std::lock_guard<std::mutex> lock(mutex);
    return { *published.load(), status, !history.empty() };
}

void EpsilonChopProcessor::loadFile(const juce::File& file)
{
    const auto ticket = loadSerial.fetch_add(1) + 1;
    {
        const std::lock_guard<std::mutex> lock(mutex);
        status = "Loading " + file.getFileName();
    }
    loader.addJob([this, file, ticket] { loadOnWorker(file, ticket); });
}

void EpsilonChopProcessor::loadOnWorker(juce::File file, std::uint64_t ticket)
{
    const auto cancelled = [this, ticket] { return loadSerial.load() != ticket; };
    const auto report = [this, &cancelled](juce::String message)
    {
        const std::lock_guard<std::mutex> lock(mutex);
        if (!cancelled())
            status = std::move(message);
    };
    if (cancelled())
        return;

    try
    {
        juce::AudioFormatManager formats;
        formats.registerBasicFormats();
        std::unique_ptr<juce::AudioFormatReader> reader(formats.createReaderFor(file));
        if (reader == nullptr)
            return report("Choose a readable WAV, AIFF, FLAC or MP3 file");
        if (!chop::validSampleSize(reader->sampleRate, static_cast<int>(reader->numChannels), reader->lengthInSamples))
            return report("Use mono or stereo audio at 8–192 kHz, up to 120 seconds and 8 million frames");

        auto sample = std::make_shared<chop::Sample>();
        const auto frames = static_cast<int>(reader->lengthInSamples);
        sample->channels = static_cast<int>(reader->numChannels);
        sample->sampleRate = reader->sampleRate;
        sample->name = file.getFileName().toStdString();
        std::array<float*, 2> pointers {};
        for (int channel = 0; channel < sample->channels; ++channel)
        {
            sample->pcm[channel].resize(static_cast<std::size_t>(frames));
            pointers[channel] = sample->pcm[channel].data();
        }
        juce::AudioBuffer<float> view(pointers.data(), sample->channels, frames);
        constexpr int decodeBlock = 65536;
        for (int first = 0; first < frames; first += decodeBlock)
        {
            if (cancelled())
                return;
            const auto length = std::min(decodeBlock, frames - first);
            if (!reader->read(&view, first, length, first, true, sample->channels > 1))
                return report("Could not decode " + file.getFileName());
            for (int channel = 0; channel < sample->channels; ++channel)
                for (int frame = first; frame < first + length; ++frame)
                    pointers[channel][frame] = safeAudio(pointers[channel][frame]);
        }

        chop::buildWaveform(*sample);
        if (!chop::analyzeTransients(*sample, cancelled))
            return;
        const std::lock_guard<std::mutex> lock(mutex);
        if (cancelled())
            return;
        auto next = std::make_unique<chop::Session>(*published.load());
        next->sample = std::move(sample);
        next->sampleRevision = ++sampleRevision;
        next->edit.manual = next->edit.mode == chop::SliceMode::manual
            ? chop::equalSlices(frames, next->edit.density) : chop::Slices {};
        history.clear();
        previewRequest.store(-1);
        status = "Loaded " + file.getFileName();
        publishLocked(std::move(next));
    }
    catch (const std::exception&)
    {
        report("Could not load " + file.getFileName());
    }
}

void EpsilonChopProcessor::edit(const Mutation& change, bool remember)
{
    const std::lock_guard<std::mutex> lock(mutex);
    const auto* current = published.load();
    auto next = std::make_unique<chop::Session>(*current);
    if (!change(*next))
        return;
    if (remember)
    {
        if (history.size() == historyLimit)
            history.erase(history.begin());
        history.push_back(current->edit);
    }
    publishLocked(std::move(next));
}

void EpsilonChopProcessor::setMode(chop::SliceMode mode)
{
    edit([mode](auto& state)
    {
        if (state.edit.mode == mode)
            return false;
        if (mode == chop::SliceMode::manual && state.sample != nullptr
            && !chop::validSlices(state.edit.manual, state.sample->length()))
            state.edit.manual = state.slices;
        state.edit.mode = mode;
        return true;
    });
}

void EpsilonChopProcessor::setDensity(int density)
{
    edit([density](auto& state)
    {
        if (density < 1 || density > chop::maxSlices || state.edit.density == density)
            return false;
        state.edit.density = density;
        return true;
    });
}

void EpsilonChopProcessor::setBank(int bank)
{
    edit([bank](auto& state)
    {
        if (bank < 0 || bank >= chop::bankCount || bank == state.edit.bank)
            return false;
        state.edit.bank = bank;
        return true;
    }, false);
}

void EpsilonChopProcessor::applyPreset(int preset)
{
    edit([preset](auto& state)
    {
        state.edit.patterns[state.edit.bank] = chop::makePreset(preset);
        return true;
    });
}

void EpsilonChopProcessor::randomize()
{
    edit([](auto& state)
    {
        return chop::randomizeSlices(state.edit.patterns[state.edit.bank], state.slices.count, state.seed);
    });
}

void EpsilonChopProcessor::moveAndTrim()
{
    edit([](auto& state)
    {
        return chop::moveAndTrim(state.edit.patterns[state.edit.bank], state.seed);
    });
}

void EpsilonChopProcessor::undo()
{
    const std::lock_guard<std::mutex> lock(mutex);
    if (history.empty())
        return;
    auto next = std::make_unique<chop::Session>(*published.load());
    next->edit = history.back();
    history.pop_back();
    publishLocked(std::move(next));
}

void EpsilonChopProcessor::setStep(int index, int slice, int gate)
{
    if (index < 0 || index >= chop::stepCount || slice < -1 || slice >= chop::maxSlices || gate < 10 || gate > 100)
        return;
    edit([=](auto& state)
    {
        auto& step = state.edit.patterns[state.edit.bank][index];
        if (step.slice == slice && step.gate == gate)
            return false;
        step = { slice, gate };
        return true;
    });
}

void EpsilonChopProcessor::editBoundary(int index, int position)
{
    edit([=](auto& state)
    {
        if (state.sample == nullptr || state.edit.mode != chop::SliceMode::manual)
            return false;
        const auto spacing = markerSpacing(*state.sample);
        if (index < 0)
            return chop::insertBoundary(state.edit.manual, position, spacing);
        if (position < 0)
            return chop::removeBoundary(state.edit.manual, index);
        return chop::moveBoundary(state.edit.manual, index, position, spacing);
    });
}

void EpsilonChopProcessor::getStateInformation(juce::MemoryBlock& data)
{
    const auto snapshot = editorState().session;
    juce::MemoryOutputStream out(data, false);
    out.writeInt(stateMagic);
    out.writeInt(stateVersion);
    out.writeFloat(outputParameter->load());
    out.writeInt(patternParameter->load() >= 0.5f ? 1 : 0);
    out.writeInt64(static_cast<juce::int64>(snapshot.seed));
    writeEdit(out, snapshot.edit);
    writeSample(out, snapshot.sample.get());
    out.flush();
}

void EpsilonChopProcessor::setStateInformation(const void* data, int size)
{
    if (data == nullptr || size < 44 || size > 2 * chop::maxSampleFrames * 4 + 8192)
        return;
    try
    {
        juce::MemoryInputStream in(data, static_cast<std::size_t>(size), false);
        if (in.readInt() != stateMagic || in.readInt() != stateVersion)
            return;
        const auto gain = in.readFloat();
        const auto run = in.readInt();
        const auto seed = in.readInt64();
        auto next = std::make_unique<chop::Session>();
        if (!std::isfinite(gain) || gain < -24.01f || gain > 6.01f || run < 0 || run > 1
            || seed < 0 || seed > 0xffffffffLL || !readEdit(in, next->edit) || !readSample(in, next->sample))
            return;
        if (next->edit.manual.count > 0 && (next->sample == nullptr
            || !chop::validSlices(next->edit.manual, next->sample->length())))
            return;
        next->seed = static_cast<std::uint32_t>(seed);

        {
            const std::lock_guard<std::mutex> lock(mutex);
            loadSerial.fetch_add(1);
            next->sampleRevision = ++sampleRevision;
            history.clear();
            previewRequest.store(-1);
            status = next->sample != nullptr ? "Restored " + juce::String(next->sample->name)
                                             : "Drop a sample or choose Load Sample";
            publishLocked(std::move(next));
        }
        auto* output = parameters.getParameter("output");
        output->setValueNotifyingHost(output->convertTo0to1(gain));
        parameters.getParameter("pattern")->setValueNotifyingHost(static_cast<float>(run));
    }
    catch (const std::exception&)
    {
        // Leave the current state available if a host passes an unusable chunk.
    }
}

juce::AudioProcessorEditor* EpsilonChopProcessor::createEditor()
{
    return new EpsilonChopEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new EpsilonChopProcessor();
}
