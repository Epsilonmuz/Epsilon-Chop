#include "PluginEditor.h"

#include <algorithm>
#include <cmath>
#include <iterator>

namespace
{
const juce::Colour background { 0xff10151e };
const juce::Colour panel { 0xff171f2d };
const juce::Colour well { 0xff121b29 };
const juce::Colour raised { 0xff263247 };
const juce::Colour border { 0xff39485e };
const juce::Colour foreground { 0xfff0f3f8 };
const juce::Colour muted { 0xffa3b4c9 };
const juce::Colour amber { 0xffffb76f };
const juce::Colour teal { 0xff68d7cf };
const juce::Colour purple { 0xffa5a0f4 };
constexpr int outer = 23;
constexpr int rowHeight = 31;

juce::Font font(float size, bool bold = false)
{
    return juce::Font(juce::FontOptions(size, bold ? juce::Font::bold : juce::Font::plain));
}

juce::Colour sliceColour(int slice)
{
    const std::array<juce::Colour, 3> colours { amber, teal, purple };
    return colours[static_cast<std::size_t>(slice % 3)];
}

juce::String twoDigits(int value)
{
    return juce::String(value).paddedLeft('0', 2);
}

bool supportedFile(const juce::File& file)
{
    return file.hasFileExtension("wav;wave;aif;aiff;flac;mp3");
}
}

EpsilonChopEditor::EpsilonChopEditor(EpsilonChopProcessor& owner)
    : AudioProcessorEditor(&owner), processor(owner), view(owner.editorState())
{
    look.setColour(juce::ComboBox::backgroundColourId, raised);
    look.setColour(juce::ComboBox::outlineColourId, border);
    look.setColour(juce::ComboBox::textColourId, foreground);
    look.setColour(juce::PopupMenu::backgroundColourId, panel);
    look.setColour(juce::PopupMenu::textColourId, foreground);
    look.setColour(juce::PopupMenu::highlightedBackgroundColourId, raised);
    look.setColour(juce::Slider::backgroundColourId, border);
    look.setColour(juce::Slider::trackColourId, amber);
    look.setColour(juce::Slider::thumbColourId, foreground);
    look.setColour(juce::Slider::textBoxTextColourId, foreground);
    look.setColour(juce::Slider::textBoxBackgroundColourId, well);
    look.setColour(juce::Slider::textBoxOutlineColourId, border);
    setLookAndFeel(&look);

    auto button = [this](juce::TextButton& control)
    {
        control.setColour(juce::TextButton::buttonColourId, raised);
        control.setColour(juce::TextButton::buttonOnColourId, amber);
        control.setColour(juce::TextButton::textColourOffId, foreground);
        control.setColour(juce::TextButton::textColourOnId, background);
        addAndMakeVisible(control);
    };
    for (auto* control : { &load, &stop, &run, &random, &move, &undo })
        button(*control);
    load.setColour(juce::TextButton::buttonColourId, amber);
    load.setColour(juce::TextButton::textColourOffId, background);
    random.setColour(juce::TextButton::buttonColourId, amber);
    random.setColour(juce::TextButton::textColourOffId, background);
    move.setColour(juce::TextButton::buttonColourId, teal);
    move.setColour(juce::TextButton::textColourOffId, background);
    run.setClickingTogglesState(true);

    for (int index = 0; index < chop::bankCount; ++index)
    {
        auto& control = banks[index];
        control.setButtonText(juce::String::charToString(static_cast<juce::juce_wchar>('A' + index)));
        button(control);
        control.onClick = [this, index] { processor.setBank(index); refresh(); };
    }

    for (auto* box : { &mode, &density, &preset, &stepSlice })
        addAndMakeVisible(*box);
    mode.addItem("Grid", 1);
    mode.addItem("Transient", 2);
    mode.addItem("Manual", 3);
    for (int count : { 4, 8, 16, 32 })
        density.addItem(juce::String(count) + " chops", count);
    preset.setTextWhenNothingSelected("Load Groove");
    preset.addItem("Straight", 1);
    preset.addItem("Jersey Bounce", 2);
    preset.addItem("Drill Space", 3);
    preset.addItem("Dembow Pocket", 4);

    for (auto* slider : { &output, &gate })
    {
        slider->setSliderStyle(juce::Slider::LinearHorizontal);
        slider->setTextBoxStyle(juce::Slider::TextBoxRight, false, 56, 23);
        slider->setScrollWheelEnabled(false);
        addAndMakeVisible(*slider);
    }
    output.setTitle("Output volume");
    gate.setTitle("Step gate");
    gate.setRange(10.0, 100.0, 1.0);
    gate.setTextValueSuffix("%");
    outputAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        processor.parameters, "output", output);
    runAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        processor.parameters, "pattern", run);

    load.onClick = [this] { chooseSample(); };
    stop.onClick = [this] { processor.stopPreview(); };
    random.onClick = [this] { processor.randomize(); refresh(); };
    move.onClick = [this] { processor.moveAndTrim(); refresh(); };
    undo.onClick = [this] { processor.undo(); refresh(); };
    mode.onChange = [this]
    {
        if (mode.getSelectedId() > 0)
            processor.setMode(static_cast<chop::SliceMode>(mode.getSelectedId() - 1));
        refresh();
    };
    density.onChange = [this] { processor.setDensity(density.getSelectedId()); refresh(); };
    preset.onChange = [this]
    {
        const auto id = preset.getSelectedId();
        if (id > 0)
            processor.applyPreset(id - 1);
        preset.setSelectedId(0, juce::dontSendNotification);
        refresh();
    };
    stepSlice.onChange = [this]
    {
        const auto id = stepSlice.getSelectedId();
        if (id > 0)
            processor.setStep(selectedStep, id - 2, juce::roundToInt(gate.getValue()));
        refresh();
    };
    gate.onDragStart = [this] { draggingGate = true; };
    gate.onDragEnd = [this] { draggingGate = false; setGateFromControl(); };
    gate.onValueChange = [this] { if (!draggingGate) setGateFromControl(); };

    setResizable(true, true);
    setResizeLimits(880, 570, 1460, 900);
    setSize(1040, 648);
    refresh();
    startTimerHz(30);
}

EpsilonChopEditor::~EpsilonChopEditor()
{
    stopTimer();
    chooser.reset();
    setLookAndFeel(nullptr);
}

void EpsilonChopEditor::chooseSample()
{
    chooser = std::make_unique<juce::FileChooser>("Choose a sample", juce::File {},
                                                  "*.wav;*.wave;*.aif;*.aiff;*.flac;*.mp3");
    juce::Component::SafePointer<EpsilonChopEditor> safe(this);
    chooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [safe](const juce::FileChooser& result)
        {
            if (safe != nullptr && result.getResult().existsAsFile())
                safe->processor.loadFile(result.getResult());
        });
}

void EpsilonChopEditor::timerCallback()
{
    refresh();
}

void EpsilonChopEditor::refresh()
{
    view = processor.editorState();
    selectedChop = juce::jlimit(0, std::max(0, view.session.slices.count - 1), selectedChop);
    mode.setSelectedId(static_cast<int>(view.session.edit.mode) + 1, juce::dontSendNotification);
    density.setSelectedId(view.session.edit.density, juce::dontSendNotification);
    density.setEnabled(view.session.edit.mode != chop::SliceMode::manual);
    for (int index = 0; index < chop::bankCount; ++index)
        banks[index].setToggleState(index == view.session.edit.bank, juce::dontSendNotification);

    const auto& pattern = view.session.edit.patterns[view.session.edit.bank];
    const auto hasHits = std::any_of(pattern.begin(), pattern.end(), [](const auto& step) { return step.slice >= 0; });
    random.setEnabled(view.session.slices.count > 1 && hasHits);
    move.setEnabled(view.session.sample != nullptr && hasHits);
    stop.setEnabled(view.session.sample != nullptr);
    undo.setEnabled(view.canUndo);
    syncStepControls();
    repaint();
}

void EpsilonChopEditor::syncStepControls()
{
    const auto sliceCount = view.session.slices.count;
    if (displayedSliceCount != sliceCount)
    {
        stepSlice.clear(juce::dontSendNotification);
        stepSlice.addItem("Rest", 1);
        for (int index = 0; index < sliceCount; ++index)
            stepSlice.addItem("Chop " + twoDigits(index + 1), index + 2);
        displayedSliceCount = sliceCount;
    }
    const auto step = view.session.edit.patterns[view.session.edit.bank][selectedStep];
    stepSlice.setSelectedId(displaySlice(step.slice) + 2, juce::dontSendNotification);
    stepSlice.setEnabled(sliceCount > 0);
    gate.setEnabled(step.slice >= 0 && sliceCount > 0);
    if (!draggingGate)
        gate.setValue(step.gate, juce::dontSendNotification);
}

int EpsilonChopEditor::displaySlice(int slice) const
{
    return slice < 0 || view.session.slices.count == 0 ? -1 : slice % view.session.slices.count;
}

void EpsilonChopEditor::setGateFromControl()
{
    const auto slice = view.session.edit.patterns[view.session.edit.bank][selectedStep].slice;
    if (slice >= 0)
        processor.setStep(selectedStep, slice, juce::roundToInt(gate.getValue()));
    refresh();
}

void EpsilonChopEditor::resized()
{
    const auto width = getWidth();
    const auto height = getHeight();
    load.setBounds(width - outer - 149, 27, 149, 38);
    output.setBounds(width - outer - 348, 29, 179, 31);
    mode.setBounds(outer, 89, 127, rowHeight);
    density.setBounds(outer + 136, 89, 110, rowHeight);
    stop.setBounds(outer + 255, 89, 115, rowHeight);

    waveArea = { outer, 133, width - 2 * outer, height - 365 };
    const auto patternY = waveArea.getBottom() + 15;
    run.setBounds(outer + 142, patternY, 127, rowHeight);
    for (int bank = 0; bank < chop::bankCount; ++bank)
        banks[bank].setBounds(outer + 281 + bank * 36, patternY, 32, rowHeight);
    preset.setBounds(width - outer - 154, patternY, 154, rowHeight);

    stepArea = { outer, patternY + 43, width - 2 * outer, 69 };
    actionsArea = { outer, stepArea.getBottom() + 14, width - 2 * outer, 36 };
    random.setBounds(actionsArea.getX(), actionsArea.getY(), 118, actionsArea.getHeight());
    move.setBounds(actionsArea.getX() + 127, actionsArea.getY(), 144, actionsArea.getHeight());
    undo.setBounds(actionsArea.getX() + 280, actionsArea.getY(), 67, actionsArea.getHeight());
    stepSlice.setBounds(width - outer - 304, actionsArea.getY(), 110, actionsArea.getHeight());
    gate.setBounds(width - outer - 160, actionsArea.getY() + 3, 160, actionsArea.getHeight() - 6);
}

void EpsilonChopEditor::paint(juce::Graphics& g)
{
    g.fillAll(background);
    g.setColour(amber);
    g.setFont(font(30.0f, true));
    g.drawText("EPSILON CHOP", outer, 14, 300, 37, juce::Justification::centredLeft);
    g.setColour(muted);
    g.setFont(font(11.5f));
    g.drawText("EPSILON SOUNDS  /  SAMPLE INSTRUMENT", outer, 53, 360, 19, juce::Justification::centredLeft);
    g.drawText("OUTPUT", getWidth() - outer - 349, 13, 72, 15, juce::Justification::centredLeft);
    g.drawFittedText(view.status, getWidth() / 2, 90, getWidth() / 2 - outer, 28, juce::Justification::centredRight, 1);

    paintWaveform(g);
    g.setColour(foreground);
    g.setFont(font(14.0f, true));
    g.drawText("16-STEP PATTERN", outer, waveArea.getBottom() + 16, 137, 30, juce::Justification::centredLeft);
    paintSteps(g);
    g.setColour(muted);
    g.setFont(font(11.5f, true));
    g.drawText("STEP " + twoDigits(selectedStep + 1), getWidth() - outer - 375, actionsArea.getY(),
               68, 36, juce::Justification::centredRight);
    g.drawText("GATE", getWidth() - outer - 194, actionsArea.getY(), 30, 36, juce::Justification::centredRight);

    const auto manual = view.session.edit.mode == chop::SliceMode::manual;
    const auto hint = manual ? "Double-click to add a marker. Drag to move it. Right-click to remove it."
                             : "Click a chop to audition. In FL Studio, play from MIDI note 36 or turn on Play Pattern.";
    g.setFont(font(12.0f));
    g.drawFittedText(hint, outer, actionsArea.getBottom() + 13, getWidth() - 2 * outer, 20,
                     juce::Justification::centredLeft, 1);
}

juce::Rectangle<int> EpsilonChopEditor::waveformBody() const
{
    return waveArea.reduced(13, 0).withTrimmedTop(37).withTrimmedBottom(26);
}

void EpsilonChopEditor::paintWaveform(juce::Graphics& g) const
{
    g.setColour(panel);
    g.fillRoundedRectangle(waveArea.toFloat(), 11.0f);
    g.setColour(draggingFile ? amber : border);
    g.drawRoundedRectangle(waveArea.toFloat(), 11.0f, 1.0f);
    g.setColour(muted);
    g.setFont(font(11.5f, true));
    g.drawText("WAVEFORM", waveArea.getX() + 14, waveArea.getY() + 10, 118, 20, juce::Justification::centredLeft);

    const auto& state = view.session;
    const auto* sample = state.sample.get();
    if (sample == nullptr)
    {
        g.setColour(amber);
        g.setFont(font(21.0f, true));
        g.drawText("Drop your sample here", waveArea, juce::Justification::centred);
        g.setColour(muted);
        g.setFont(font(12.0f));
        g.drawText("WAV  /  AIFF  /  FLAC  /  MP3", waveArea.getX(), waveArea.getCentreY() + 18,
                   waveArea.getWidth(), 22, juce::Justification::centred);
        return;
    }

    auto details = juce::String(sample->name) + "  |  " + juce::String(sample->length() / sample->sampleRate, 2)
        + " s  |  " + juce::String(sample->sampleRate / 1000.0, 1) + " kHz  |  "
        + juce::String(state.slices.count) + " chops";
    if (state.edit.mode == chop::SliceMode::transient && sample->transientCount == 0)
        details += "  |  grid fallback";
    g.setFont(font(12.0f));
    g.drawFittedText(details, waveArea.getX() + 130, waveArea.getY() + 10, waveArea.getWidth() - 146, 20,
                     juce::Justification::centredRight, 1);

    const auto body = waveformBody().toFloat();
    g.setColour(well);
    g.fillRect(body);
    const auto xAt = [&body, sample](int frame)
    {
        return body.getX() + body.getWidth() * static_cast<float>(frame) / static_cast<float>(sample->length());
    };
    const auto edges = [this, &state](int index)
    {
        return dragMarker == index && dragRevision == state.revision ? dragFrame : state.slices.edge[index];
    };
    for (int slice = 0; slice < state.slices.count; ++slice)
    {
        const auto first = xAt(edges(slice));
        const auto last = xAt(edges(slice + 1));
        const auto colour = sliceColour(slice);
        g.setColour(colour.withAlpha(slice == selectedChop ? 0.16f : 0.065f));
        g.fillRect(first, body.getY(), last - first, body.getHeight());
        g.setColour(colour.withAlpha(0.7f));
        g.drawVerticalLine(juce::roundToInt(first), body.getY(), body.getBottom());
        if (last - first > 21.0f)
        {
            g.setFont(font(10.0f, true));
            g.drawText(twoDigits(slice + 1), juce::roundToInt(first) + 3, juce::roundToInt(body.getBottom()) + 3,
                       juce::roundToInt(last - first) - 6, 17, juce::Justification::centredLeft);
        }
    }

    auto largest = 0.08f;
    for (const auto& peak : sample->waveform)
        largest = std::max({ largest, std::abs(peak.low), std::abs(peak.high) });
    const auto scale = body.getHeight() * 0.46f / largest;
    const auto centre = body.getCentreY();
    juce::Path waveform;
    const auto pixelWidth = juce::roundToInt(body.getWidth());
    for (int pixel = 0; pixel < pixelWidth; ++pixel)
    {
        const auto index = pixel * chop::waveformBins / pixelWidth;
        const auto& peak = sample->waveform[index];
        const auto x = body.getX() + static_cast<float>(pixel);
        waveform.startNewSubPath(x, centre - scale * peak.high);
        waveform.lineTo(x, std::max(centre - scale * peak.low, centre - scale * peak.high + 0.5f));
    }
    g.setColour(foreground.withAlpha(0.84f));
    g.strokePath(waveform, juce::PathStrokeType(1.0f));
    const auto position = processor.playFrame();
    if (position >= 0 && position < sample->length())
    {
        g.setColour(amber);
        g.drawVerticalLine(juce::roundToInt(xAt(position)), body.getY(), body.getBottom());
    }
}

juce::Rectangle<int> EpsilonChopEditor::stepBounds(int index) const
{
    constexpr int gap = 5;
    const auto stepWidth = stepArea.getWidth() + gap;
    const auto start = stepArea.getX() + stepWidth * index / chop::stepCount;
    const auto end = stepArea.getX() + stepWidth * (index + 1) / chop::stepCount;
    return { start, stepArea.getY(), end - start - gap, stepArea.getHeight() };
}

void EpsilonChopEditor::paintSteps(juce::Graphics& g) const
{
    const auto& pattern = view.session.edit.patterns[view.session.edit.bank];
    const auto play = processor.playStep();
    for (int index = 0; index < chop::stepCount; ++index)
    {
        const auto bounds = stepBounds(index);
        const auto slice = displaySlice(pattern[index].slice);
        const auto colour = slice >= 0 ? sliceColour(slice) : muted;
        g.setColour(index == play ? raised.brighter(0.21f) : (index % 4 == 0 ? raised : panel));
        g.fillRoundedRectangle(bounds.toFloat(), 5.0f);
        g.setColour(index == selectedStep ? amber : border);
        g.drawRoundedRectangle(bounds.toFloat(), 5.0f, index == selectedStep ? 1.5f : 0.6f);

        g.setFont(font(10.0f, true));
        g.setColour(muted);
        g.drawText(twoDigits(index + 1), bounds.withHeight(20), juce::Justification::centred);
        g.setFont(font(19.0f, true));
        g.setColour(colour);
        const auto label = slice >= 0 ? twoDigits(slice + 1) : juce::String("-");
        g.drawText(label, bounds.withTrimmedTop(16).withHeight(32), juce::Justification::centred);
        if (slice >= 0)
        {
            const auto barWidth = static_cast<float>(bounds.getWidth() - 14) * pattern[index].gate * 0.01f;
            g.fillRoundedRectangle(static_cast<float>(bounds.getX() + 7), static_cast<float>(bounds.getBottom() - 10),
                                   barWidth, 3.0f, 1.5f);
        }
    }
}

int EpsilonChopEditor::frameAt(int x) const
{
    const auto* sample = view.session.sample.get();
    if (sample == nullptr)
        return 0;
    const auto body = waveformBody();
    const auto fraction = static_cast<double>(x - body.getX()) / body.getWidth();
    return juce::jlimit(0, sample->length() - 1, juce::roundToInt(fraction * sample->length()));
}

int EpsilonChopEditor::markerNear(int x) const
{
    const auto* sample = view.session.sample.get();
    if (sample == nullptr)
        return -1;
    const auto body = waveformBody();
    const auto& slices = view.session.slices;
    int nearest = -1;
    int distance = 7;
    for (int index = 1; index < slices.count; ++index)
    {
        const auto position = body.getX() + juce::roundToInt(static_cast<double>(body.getWidth())
                                                            * slices.edge[index] / sample->length());
        if (std::abs(x - position) < distance)
        {
            nearest = index;
            distance = std::abs(x - position);
        }
    }
    return nearest;
}

void EpsilonChopEditor::mouseDown(const juce::MouseEvent& event)
{
    if (view.session.sample == nullptr)
        return;
    if (waveformBody().contains(event.getPosition()))
    {
        const auto marker = view.session.edit.mode == chop::SliceMode::manual ? markerNear(event.x) : -1;
        if (event.mods.isPopupMenu())
        {
            if (marker >= 0)
                processor.editBoundary(marker, -1);
        }
        else if (marker >= 0)
        {
            dragMarker = marker;
            dragFrame = view.session.slices.edge[marker];
            dragRevision = view.session.revision;
        }
        else if (event.getNumberOfClicks() < 2)
        {
            const auto& slices = view.session.slices;
            const auto end = slices.edge.begin() + slices.count + 1;
            const auto found = std::upper_bound(slices.edge.begin(), end, frameAt(event.x));
            selectedChop = static_cast<int>(std::distance(slices.edge.begin(), found)) - 1;
            processor.preview(selectedChop);
        }
        refresh();
        return;
    }

    for (int index = 0; index < chop::stepCount; ++index)
    {
        if (!stepBounds(index).contains(event.getPosition()))
            continue;
        selectedStep = index;
        if (event.mods.isPopupMenu() || event.mods.isShiftDown())
        {
            const auto step = view.session.edit.patterns[view.session.edit.bank][index];
            processor.setStep(index, step.slice < 0 ? selectedChop : -1, step.gate);
        }
        refresh();
        break;
    }
}

void EpsilonChopEditor::mouseDoubleClick(const juce::MouseEvent& event)
{
    if (view.session.sample != nullptr && view.session.edit.mode == chop::SliceMode::manual
        && waveformBody().contains(event.getPosition()) && markerNear(event.x) < 0)
    {
        processor.editBoundary(-1, frameAt(event.x));
        refresh();
    }
}

void EpsilonChopEditor::mouseDrag(const juce::MouseEvent& event)
{
    if (dragMarker < 0 || dragRevision != view.session.revision)
        return;
    const auto& slices = view.session.slices;
    const auto spacing = std::max(1, juce::roundToInt(view.session.sample->sampleRate * 0.004));
    const auto first = slices.edge[dragMarker - 1] + spacing;
    const auto last = slices.edge[dragMarker + 1] - spacing;
    if (first <= last)
        dragFrame = juce::jlimit(first, last, frameAt(event.x));
    repaint();
}

void EpsilonChopEditor::mouseUp(const juce::MouseEvent&)
{
    if (dragMarker < 0)
        return;
    if (dragRevision == view.session.revision)
        processor.editBoundary(dragMarker, dragFrame);
    dragMarker = -1;
    refresh();
}

bool EpsilonChopEditor::isInterestedInFileDrag(const juce::StringArray& files)
{
    return std::any_of(files.begin(), files.end(), [](const auto& path) { return supportedFile(juce::File(path)); });
}

void EpsilonChopEditor::fileDragEnter(const juce::StringArray&, int, int)
{
    draggingFile = true;
    repaint();
}

void EpsilonChopEditor::fileDragExit(const juce::StringArray&)
{
    draggingFile = false;
    repaint();
}

void EpsilonChopEditor::filesDropped(const juce::StringArray& files, int, int)
{
    draggingFile = false;
    const auto found = std::find_if(files.begin(), files.end(),
                                   [](const auto& path) { return supportedFile(juce::File(path)); });
    if (found != files.end())
        processor.loadFile(juce::File(*found));
    refresh();
}
