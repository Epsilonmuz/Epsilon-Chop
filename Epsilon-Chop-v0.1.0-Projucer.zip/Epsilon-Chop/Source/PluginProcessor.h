#pragma once

#include <JuceHeader.h>
#include "ChopEngine.h"

#include <atomic>
#include <functional>
#include <mutex>

class EpsilonChopProcessor final : public juce::AudioProcessor
{
public:
    EpsilonChopProcessor();
    ~EpsilonChopProcessor() override;

    void prepareToPlay(double sampleRate, int maximumBlockSize) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int size) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "Epsilon Chop"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}

    struct EditorState
    {
        chop::Session session;
        juce::String status;
        bool canUndo = false;
    };

    EditorState editorState() const;
    void loadFile(const juce::File&);
    void setMode(chop::SliceMode);
    void setDensity(int);
    void setBank(int);
    void applyPreset(int);
    void randomize();
    void moveAndTrim();
    void undo();
    void setStep(int index, int slice, int gate);
    void editBoundary(int index, int position);
    void preview(int slice) noexcept { previewRequest.store(slice, std::memory_order_relaxed); }
    void stopPreview() noexcept { previewRequest.store(-2, std::memory_order_relaxed); }
    int playStep() const noexcept { return currentStep.load(std::memory_order_relaxed); }
    int playFrame() const noexcept { return currentFrame.load(std::memory_order_relaxed); }

    juce::AudioProcessorValueTreeState parameters;

private:
    using Mutation = std::function<bool(chop::Session&)>;
    void edit(const Mutation&, bool remember = true);
    void publishLocked(std::unique_ptr<chop::Session>);
    void loadOnWorker(juce::File, std::uint64_t ticket);
    const chop::Session* acquireAudioState() noexcept;
    void reclaimLocked();

    mutable std::mutex mutex;
    std::vector<std::unique_ptr<chop::Session>> snapshots;
    std::vector<chop::Edit> history;
    juce::String status { "Drop a sample or choose Load Sample" };
    std::uint64_t revision = 0, sampleRevision = 0;
    std::atomic<const chop::Session*> published { nullptr }, audioHazard { nullptr };
    static_assert(std::atomic<const chop::Session*>::is_always_lock_free);
    std::atomic<std::uint64_t> loadSerial { 0 };
    std::atomic<int> previewRequest { -1 }, currentStep { -1 }, currentFrame { -1 };
    std::atomic<float>* outputParameter = nullptr;
    std::atomic<float>* patternParameter = nullptr;
    chop::Engine engine;
    juce::ThreadPool loader { 1 };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(EpsilonChopProcessor)
};
