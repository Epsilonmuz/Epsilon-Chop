#pragma once

#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace chop
{
constexpr int maxSlices = 32;
constexpr int stepCount = 16;
constexpr int bankCount = 4;
constexpr int firstMidiNote = 36;
constexpr int waveformBins = 1536;
constexpr int maxSampleFrames = 8'000'000;
constexpr int maxSampleSeconds = 120;

enum class SliceMode : int { grid, transient, manual };
enum class VoiceOrigin : int { midi, pattern, preview };

struct Peak { float low = 0.0f, high = 0.0f; };

struct Sample
{
    std::string name;
    double sampleRate = 44100.0;
    int channels = 0;
    std::array<std::vector<float>, 2> pcm;
    std::array<Peak, waveformBins> waveform {};
    std::array<int, maxSlices - 1> transients {};
    int transientCount = 0;

    int length() const noexcept { return static_cast<int>(pcm[0].size()); }
};

struct Slices
{
    std::array<int, maxSlices + 1> edge {};
    int count = 0;
};

struct Step
{
    int slice = -1;
    int gate = 100;
};

using Pattern = std::array<Step, stepCount>;

struct Edit
{
    SliceMode mode = SliceMode::grid;
    int density = 8;
    int bank = 0;
    Slices manual;
    std::array<Pattern, bankCount> patterns;
};

struct Session
{
    std::shared_ptr<const Sample> sample;
    Edit edit;
    Slices slices;
    std::uint64_t sampleRevision = 0;
    std::uint64_t revision = 0;
    std::uint32_t seed = 0x7f3259ac;
};

bool validSampleSize(double rate, int channels, std::int64_t frames) noexcept;
Slices equalSlices(int frames, int density) noexcept;
Slices makeSlices(const Sample&, const Edit&) noexcept;
bool validSlices(const Slices&, int frames) noexcept;
bool insertBoundary(Slices&, int position, int minimumSpacing) noexcept;
bool moveBoundary(Slices&, int index, int position, int minimumSpacing) noexcept;
bool removeBoundary(Slices&, int index) noexcept;
Pattern makePreset(int index) noexcept;
Edit defaultEdit() noexcept;
bool randomizeSlices(Pattern&, int slices, std::uint32_t& seed) noexcept;
bool moveAndTrim(Pattern&, std::uint32_t& seed) noexcept;

struct Transport
{
    double ppq = 0.0;
    double bpm = 0.0;
    bool playing = false;
};

class Engine
{
public:
    void prepare(double outputRate, float initialGain = 1.0f);
    void reset() noexcept;
    void beginBlock(const Session&, Transport, bool runPattern, int samples, float gain) noexcept;
    void trigger(int slice, float velocity, VoiceOrigin, int gateFrames = 0) noexcept;
    void stop(VoiceOrigin) noexcept;
    void render(int sampleInBlock, float& left, float& right) noexcept;
    void endBlock() noexcept { sample = nullptr; slices = nullptr; pattern = nullptr; }
    int currentStep() const noexcept { return playStep; }
    int currentFrame() const noexcept { return playFrame; }

private:
    struct Voice
    {
        double position = 0.0;
        int start = 0, end = 0;
        int frames = 0, elapsed = 0;
        int fade = 0, release = 0, releaseLength = 0;
        float velocity = 0.0f;
        VoiceOrigin origin = VoiceOrigin::midi;

        bool active() const noexcept { return elapsed < frames; }
    };

    void release(Voice&) const noexcept;
    void advancePattern(int sampleInBlock) noexcept;
    float interpolate(const float*, int first, int last, double position) const noexcept;

    const Sample* sample = nullptr;
    const Slices* slices = nullptr;
    const Pattern* pattern = nullptr;
    std::array<Voice, 8> voices {};
    std::uint64_t currentSample = 0;
    double sampleRate = 44100.0, ratio = 1.0;
    double tickStart = 0.0, tickIncrement = 0.0, expectedTick = 0.0;
    std::int64_t previousTick = 0;
    bool sequencing = false;
    int filterIndex = 0, microfadeFrames = 88, playStep = -1, playFrame = -1;
    int replacementFade = 0;
    float gain = 1.0f, gainTarget = 1.0f, gainStep = 1.0f;
    float lastLeft = 0.0f, lastRight = 0.0f, replacedLeft = 0.0f, replacedRight = 0.0f;
};
}
