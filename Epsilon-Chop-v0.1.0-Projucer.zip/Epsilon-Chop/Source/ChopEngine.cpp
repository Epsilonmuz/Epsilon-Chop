#include "ChopEngine.h"

#include <algorithm>
#include <cmath>
#include <iterator>

namespace chop
{
namespace
{
constexpr double pi = 3.14159265358979323846;
constexpr int taps = 32, phases = 64, cutoffCount = 81;
constexpr double tickEpsilon = 1.0e-8;

struct ResamplingTable
{
    using Kernel = std::array<float, taps>;
    std::array<std::array<Kernel, phases + 1>, cutoffCount> bands {};

    ResamplingTable()
    {
        for (int band = 0; band < cutoffCount; ++band)
        {
            const auto cutoff = std::exp2(-static_cast<double>(band) / 16.0);
            for (int phase = 0; phase <= phases; ++phase)
            {
                auto& kernel = bands[band][phase];
                double total = 0.0;
                for (int tap = 0; tap < taps; ++tap)
                {
                    const auto distance = tap - (taps / 2 - 1) - static_cast<double>(phase) / phases;
                    const auto x = distance / (taps / 2);
                    const auto window = std::abs(x) < 1.0
                        ? 0.42 + 0.5 * std::cos(pi * x) + 0.08 * std::cos(2.0 * pi * x) : 0.0;
                    const auto angle = pi * cutoff * distance;
                    const auto sinc = std::abs(angle) < 1.0e-12 ? 1.0 : std::sin(angle) / angle;
                    kernel[tap] = static_cast<float>(cutoff * sinc * window);
                    total += kernel[tap];
                }
                for (auto& coefficient : kernel)
                    coefficient /= static_cast<float>(total);
            }
        }
    }
};

const ResamplingTable& resamplingTable()
{
    static const ResamplingTable table;
    return table;
}

int draw(std::uint32_t& seed, int upper) noexcept
{
    seed = seed * 1664525u + 1013904223u;
    return static_cast<int>((seed >> 8u) % static_cast<unsigned>(upper));
}

float smooth(float value) noexcept
{
    return value * value * (3.0f - 2.0f * value);
}
}

bool validSampleSize(double rate, int channels, std::int64_t frames) noexcept
{
    return std::isfinite(rate) && rate >= 8000.0 && rate <= 192000.0
           && channels >= 1 && channels <= 2 && frames > 0
           && frames <= maxSampleFrames && static_cast<double>(frames) <= rate * maxSampleSeconds;
}

Slices equalSlices(int frames, int density) noexcept
{
    Slices result;
    if (frames <= 0)
        return result;

    result.count = std::min(frames, std::clamp(density, 1, maxSlices));
    for (int index = 0; index <= result.count; ++index)
        result.edge[index] = static_cast<int>((static_cast<std::int64_t>(frames) * index) / result.count);
    return result;
}

bool validSlices(const Slices& slices, int frames) noexcept
{
    if (slices.count < 1 || slices.count > maxSlices || slices.edge[0] != 0
        || slices.edge[slices.count] != frames)
        return false;
    for (int index = 1; index <= slices.count; ++index)
        if (slices.edge[index] <= slices.edge[index - 1])
            return false;
    return true;
}

Slices makeSlices(const Sample& sample, const Edit& edit) noexcept
{
    if (edit.mode == SliceMode::manual && validSlices(edit.manual, sample.length()))
        return edit.manual;

    if (edit.mode == SliceMode::transient && sample.transientCount > 0)
    {
        Slices result;
        const auto marks = std::min(sample.transientCount, std::clamp(edit.density, 1, maxSlices) - 1);
        std::copy_n(sample.transients.begin(), marks, result.edge.begin() + 1);
        std::sort(result.edge.begin() + 1, result.edge.begin() + 1 + marks);
        result.count = marks + 1;
        result.edge[result.count] = sample.length();
        if (validSlices(result, sample.length()))
            return result;
    }

    return equalSlices(sample.length(), edit.density);
}

bool insertBoundary(Slices& slices, int position, int minimumSpacing) noexcept
{
    if (slices.count < 1 || slices.count >= maxSlices
        || position <= 0 || position >= slices.edge[slices.count])
        return false;
    auto at = std::lower_bound(slices.edge.begin() + 1, slices.edge.begin() + slices.count + 1, position);
    if (position - *(at - 1) < minimumSpacing || *at - position < minimumSpacing)
        return false;
    std::move_backward(at, slices.edge.begin() + slices.count + 1, slices.edge.begin() + slices.count + 2);
    *at = position;
    ++slices.count;
    return true;
}

bool moveBoundary(Slices& slices, int index, int position, int minimumSpacing) noexcept
{
    if (index <= 0 || index >= slices.count)
        return false;
    const auto low = slices.edge[index - 1] + minimumSpacing;
    const auto high = slices.edge[index + 1] - minimumSpacing;
    if (low > high)
        return false;
    const auto moved = std::clamp(position, low, high);
    if (moved == slices.edge[index])
        return false;
    slices.edge[index] = moved;
    return true;
}

bool removeBoundary(Slices& slices, int index) noexcept
{
    if (index <= 0 || index >= slices.count)
        return false;
    std::move(slices.edge.begin() + index + 1, slices.edge.begin() + slices.count + 1,
              slices.edge.begin() + index);
    --slices.count;
    return true;
}

Pattern makePreset(int index) noexcept
{
    Pattern pattern {};
    auto hit = [&pattern](int step, int slice, int gate) { pattern[step] = { slice, gate }; };
    switch (index)
    {
        case 1:
            hit(0, 0, 85); hit(3, 1, 55); hit(6, 2, 70); hit(8, 3, 90);
            hit(10, 2, 45); hit(11, 2, 35); hit(14, 5, 85);
            break;
        case 2:
            hit(0, 0, 100); hit(4, 2, 85); hit(7, 3, 40); hit(9, 1, 100);
            hit(12, 4, 75); hit(15, 6, 40);
            break;
        case 3:
            hit(0, 0, 90); hit(3, 1, 70); hit(6, 2, 70); hit(8, 0, 90);
            hit(11, 3, 70); hit(14, 4, 55);
            break;
        default:
            for (int step = 0; step < stepCount; step += 2)
                hit(step, step / 2, 100);
            break;
    }
    return pattern;
}

Edit defaultEdit() noexcept
{
    Edit edit;
    for (int bank = 0; bank < bankCount; ++bank)
        edit.patterns[bank] = makePreset(bank);
    return edit;
}

bool randomizeSlices(Pattern& pattern, int slices, std::uint32_t& seed) noexcept
{
    if (slices < 2)
        return false;
    bool changed = false;
    Step* firstHit = nullptr;
    for (auto& step : pattern)
    {
        if (step.slice < 0)
            continue;
        if (firstHit == nullptr)
            firstHit = &step;
        const auto next = draw(seed, slices);
        changed = changed || next != step.slice;
        step.slice = next;
    }
    if (!changed && firstHit != nullptr)
    {
        firstHit->slice = (firstHit->slice + 1) % slices;
        changed = true;
    }
    return changed;
}

bool moveAndTrim(Pattern& pattern, std::uint32_t& seed) noexcept
{
    std::array<Step, stepCount> hits {};
    std::array<int, stepCount> oldPositions {}, positions {};
    int count = 0;
    for (int index = 0; index < stepCount; ++index)
    {
        positions[index] = index;
        if (pattern[index].slice >= 0)
        {
            hits[count] = pattern[index];
            oldPositions[count++] = index;
        }
    }
    if (count == 0)
        return false;

    if (count == stepCount)
    {
        const auto shift = 1 + draw(seed, stepCount - 1);
        std::rotate(hits.begin(), hits.begin() + shift, hits.end());
    }
    else
    {
        for (int index = stepCount - 1; index > 0; --index)
            std::swap(positions[index], positions[draw(seed, index + 1)]);
        std::sort(positions.begin(), positions.begin() + count);
        if (std::equal(positions.begin(), positions.begin() + count, oldPositions.begin()))
        {
            for (int index = 0; index < count; ++index)
                positions[index] = (positions[index] + 1) % stepCount;
            std::sort(positions.begin(), positions.begin() + count);
        }
    }

    Pattern moved {};
    constexpr std::array<int, 3> gates { 25, 50, 75 };
    bool changed = false;
    for (int index = 0; index < count; ++index)
    {
        auto hit = hits[index];
        hit.gate = std::min(hit.gate, gates[draw(seed, static_cast<int>(gates.size()))]);
        moved[positions[index]] = hit;
    }
    for (int index = 0; index < stepCount; ++index)
        changed = changed || moved[index].slice != pattern[index].slice || moved[index].gate != pattern[index].gate;
    pattern = moved;
    return changed;
}

void Engine::prepare(double outputRate, float initialGain)
{
    (void) resamplingTable();
    sampleRate = std::isfinite(outputRate) && outputRate >= 8000.0 ? outputRate : 44100.0;
    microfadeFrames = std::max(1, static_cast<int>(std::lround(sampleRate * 0.002)));
    gain = gainTarget = initialGain;
    gainStep = static_cast<float>(1.0 - std::exp(-1.0 / (sampleRate * 0.008)));
    reset();
}

void Engine::reset() noexcept
{
    endBlock();
    voices = {};
    currentSample = 0;
    sequencing = false;
    playStep = playFrame = -1;
    lastLeft = lastRight = 0.0f;
    replacementFade = 0;
}

void Engine::beginBlock(const Session& session, Transport transport,
                        bool runPattern, int samples, float outputGain) noexcept
{
    sample = session.sample.get();
    slices = &session.slices;
    pattern = &session.edit.patterns[session.edit.bank];
    gainTarget = outputGain;

    if (session.sampleRevision != currentSample)
    {
        currentSample = session.sampleRevision;
        replacedLeft = lastLeft;
        replacedRight = lastRight;
        replacementFade = microfadeFrames;
        voices = {};
        sequencing = false;
        playFrame = -1;
        ratio = sample != nullptr ? sample->sampleRate / sampleRate : 1.0;
        filterIndex = std::clamp(static_cast<int>(std::ceil(16.0 * std::log2(std::max(1.0, ratio)))),
                                 0, cutoffCount - 1);
    }

    const auto running = sample != nullptr && runPattern && transport.playing
                         && std::isfinite(transport.ppq) && std::abs(transport.ppq) < 1.0e9
                         && std::isfinite(transport.bpm) && transport.bpm >= 10.0 && transport.bpm <= 999.0;
    if (!running)
    {
        if (sequencing)
            stop(VoiceOrigin::pattern);
        sequencing = false;
        playStep = -1;
        return;
    }

    tickStart = transport.ppq * 4.0;
    tickIncrement = transport.bpm / (15.0 * sampleRate);
    if (!sequencing || std::abs(tickStart - expectedTick) > 2.0 * tickIncrement)
    {
        stop(VoiceOrigin::pattern);
        previousTick = static_cast<std::int64_t>(std::floor(tickStart - tickIncrement + tickEpsilon));
        playStep = -1;
    }
    expectedTick = tickStart + samples * tickIncrement;
    sequencing = true;
}

void Engine::release(Voice& voice) const noexcept
{
    if (!voice.active() || voice.releaseLength != 0)
        return;
    voice.release = voice.releaseLength = std::min(microfadeFrames, voice.frames - voice.elapsed);
}

void Engine::stop(VoiceOrigin origin) noexcept
{
    for (auto& voice : voices)
        if (voice.origin == origin)
            release(voice);
}

void Engine::trigger(int slice, float velocity, VoiceOrigin origin, int gateFrames) noexcept
{
    if (sample == nullptr || slice < 0 || slice >= slices->count)
        return;
    for (auto& voice : voices)
        release(voice);

    auto voice = std::find_if(voices.begin(), voices.end(), [](const auto& v) { return !v.active(); });
    if (voice == voices.end())
        voice = std::min_element(voices.begin(), voices.end(),
                                [](const auto& a, const auto& b) { return a.release < b.release; });

    const auto first = slices->edge[slice];
    const auto last = slices->edge[slice + 1];
    const auto natural = std::max(1, static_cast<int>(std::ceil((last - first) / ratio)));
    const auto length = gateFrames > 0 ? std::min(natural, gateFrames) : natural;
    *voice = { static_cast<double>(first), first, last, length, 0,
               std::min(microfadeFrames, (length - 1) / 2), 0, 0,
               std::clamp(velocity, 0.0f, 1.0f), origin };
    playFrame = first;
}

void Engine::advancePattern(int sampleInBlock) noexcept
{
    if (!sequencing)
        return;
    const auto tick = static_cast<std::int64_t>(std::floor(tickStart + sampleInBlock * tickIncrement + tickEpsilon));
    if (tick == previousTick)
        return;

    previousTick = tick;
    playStep = static_cast<int>((tick % stepCount + stepCount) % stepCount);
    const auto step = (*pattern)[playStep];
    if (step.slice >= 0 && slices->count > 0)
    {
        const auto duration = std::max(1, static_cast<int>(std::lround((0.01 * step.gate) / tickIncrement)));
        trigger(step.slice % slices->count, 1.0f, VoiceOrigin::pattern, duration);
    }
}

float Engine::interpolate(const float* pcm, int first, int last, double position) const noexcept
{
    const auto integral = static_cast<int>(position);
    if (ratio == 1.0)
        return pcm[std::clamp(integral, first, last - 1)];

    const auto phase = static_cast<int>((position - integral) * phases + 0.5);
    const auto& kernel = resamplingTable().bands[filterIndex][phase];
    const auto start = integral - (taps / 2 - 1);
    float sum = 0.0f;
    for (int tap = 0; tap < taps; ++tap)
        sum += kernel[tap] * pcm[std::clamp(start + tap, first, last - 1)];
    return sum;
}

void Engine::render(int sampleInBlock, float& left, float& right) noexcept
{
    advancePattern(sampleInBlock);
    left = right = 0.0f;
    playFrame = -1;
    if (sample != nullptr)
    {
        for (auto& voice : voices)
        {
            if (!voice.active())
                continue;

            auto envelope = 1.0f;
            if (voice.fade > 0)
            {
                const auto distance = std::min(voice.elapsed, voice.frames - voice.elapsed - 1);
                envelope = smooth(std::min(1.0f, static_cast<float>(distance) / static_cast<float>(voice.fade)));
            }
            if (voice.releaseLength > 0)
            {
                envelope *= smooth(static_cast<float>(voice.release - 1) / static_cast<float>(voice.releaseLength));
                if (--voice.release == 0)
                    voice.frames = voice.elapsed + 1;
            }

            const auto amp = voice.velocity * envelope;
            const auto l = interpolate(sample->pcm[0].data(), voice.start, voice.end, voice.position);
            const auto r = sample->channels == 2
                ? interpolate(sample->pcm[1].data(), voice.start, voice.end, voice.position) : l;
            left += amp * l;
            right += amp * r;
            if (voice.releaseLength == 0)
                playFrame = std::min(voice.end - 1, static_cast<int>(voice.position));
            voice.position += ratio;
            ++voice.elapsed;
        }
    }

    gain += gainStep * (gainTarget - gain);
    left *= gain;
    right *= gain;
    if (replacementFade > 0)
    {
        const auto tail = smooth(static_cast<float>(replacementFade) / static_cast<float>(microfadeFrames));
        left += replacedLeft * tail;
        right += replacedRight * tail;
        --replacementFade;
    }
    lastLeft = left;
    lastRight = right;
}
}
