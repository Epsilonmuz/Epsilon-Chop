#include "PluginProcessor.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <thread>

namespace
{
constexpr int rate = 48000;
constexpr int frameCount = rate * 4;
constexpr std::array<double, 7> onsets { 0.0, 0.47, 0.96, 1.49, 2.02, 2.53, 3.12 };

void require(bool condition, const char* message)
{
    if (!condition)
        throw std::runtime_error(message);
}

struct TempFolder
{
    juce::File path = juce::File::getSpecialLocation(juce::File::tempDirectory)
                       .getChildFile("epsilon-chop-" + juce::Uuid().toString());

    TempFolder() { require(path.createDirectory().wasOk(), "create fixture folder"); }
    ~TempFolder() { path.deleteRecursively(); }
};

void writeFixture(const juce::File& path)
{
    juce::FileOutputStream stream(path);
    require(stream.openedOk(), "open WAV fixture");
    const auto payload = frameCount * 4;
    stream.write("RIFF", 4);
    stream.writeInt(36 + payload);
    stream.write("WAVEfmt ", 8);
    stream.writeInt(16);
    stream.writeShort(1);
    stream.writeShort(2);
    stream.writeInt(rate);
    stream.writeInt(rate * 4);
    stream.writeShort(4);
    stream.writeShort(16);
    stream.write("data", 4);
    stream.writeInt(payload);
    for (int index = 0; index < frameCount; ++index)
    {
        const auto time = static_cast<double>(index) / rate;
        double left = 0.0, right = 0.0;
        for (std::size_t hit = 0; hit < onsets.size(); ++hit)
        {
            const auto age = time - onsets[hit];
            if (age < 0.0 || age > 0.18)
                continue;
            const auto amplitude = (0.72 - 0.065 * hit) * std::exp(-30.0 * age);
            const auto wave = std::sin(juce::MathConstants<double>::twoPi * (104.0 + 28.0 * hit) * age);
            const auto click = 0.11 * std::exp(-165.0 * age)
                * std::sin(juce::MathConstants<double>::twoPi * 1620.0 * age);
            left += amplitude * wave + click;
            right += 0.75 * amplitude * wave - click;
        }
        stream.writeShort(static_cast<short>(32760.0 * left));
        stream.writeShort(static_cast<short>(32760.0 * right));
    }
    stream.flush();
}

EpsilonChopProcessor::EditorState waitForSample(EpsilonChopProcessor& processor)
{
    for (int attempt = 0; attempt < 800; ++attempt)
    {
        auto state = processor.editorState();
        if (state.session.sample != nullptr)
            return state;
        if (!state.status.startsWith("Loading"))
            throw std::runtime_error(state.status.toStdString());
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    throw std::runtime_error("sample import timed out");
}

bool samePattern(const chop::Pattern& a, const chop::Pattern& b)
{
    return std::equal(a.begin(), a.end(), b.begin(),
                      [](auto left, auto right) { return left.slice == right.slice && left.gate == right.gate; });
}

juce::AudioBuffer<float> renderNote(EpsilonChopProcessor& processor)
{
    processor.releaseResources();
    processor.prepareToPlay(rate, 512);
    juce::AudioBuffer<float> audio(2, 512);
    juce::MidiBuffer midi;
    midi.addEvent(juce::MidiMessage::noteOn(1, chop::firstMidiNote, static_cast<juce::uint8>(120)), 37);
    processor.processBlock(audio, midi);
    require(midi.isEmpty(), "instrument does not pass through MIDI");
    require(audio.getMagnitude(0, 37) == 0.0f, "MIDI offset preserves silence before note");
    require(audio.getMagnitude(37, 475) > 0.10f, "MIDI triggers the loaded sample");
    return audio;
}

class TestPlayHead final : public juce::AudioPlayHead
{
public:
    juce::Optional<PositionInfo> getPosition() const override
    {
        PositionInfo position;
        position.setBpm(120.0);
        position.setPpqPosition(ppq);
        position.setIsPlaying(playing);
        return position;
    }

    bool playing = true;
    double ppq = 0.0;
};

void checkPatternTransport(EpsilonChopProcessor& processor)
{
    TestPlayHead playhead;
    processor.setPlayHead(&playhead);
    processor.parameters.getParameter("pattern")->setValueNotifyingHost(1.0f);
    processor.releaseResources();
    processor.prepareToPlay(rate, 512);

    juce::AudioBuffer<float> audio(2, 512);
    juce::MidiBuffer midi;
    processor.processBlock(audio, midi);
    require(processor.playStep() == 0 && audio.getMagnitude(0, 512) > 0.10f, "host downbeat fires step one");
    playhead.playing = false;
    processor.processBlock(audio, midi);
    require(processor.playStep() == -1 && audio.getMagnitude(120, 392) == 0.0f,
            "transport stop releases the pattern voice");
    processor.setPlayHead(nullptr);
    processor.parameters.getParameter("pattern")->setValueNotifyingHost(0.0f);
}

void savePreview(EpsilonChopProcessor& processor, const juce::File& path)
{
    processor.setMode(chop::SliceMode::grid);
    processor.setDensity(8);
    processor.setBank(1);
    processor.applyPreset(1);
    std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
    const auto image = editor->createComponentSnapshot(editor->getLocalBounds(), true, 1.5f);
    require(image.isValid(), "render editor image");
    juce::FileOutputStream out(path);
    require(out.openedOk() && juce::PNGImageFormat().writeImageToStream(image, out), "write editor preview");
}

void run(const char* previewPath)
{
    TempFolder fixture;
    const auto input = fixture.path.getChildFile("Jersey-Chop-Demo.wav");
    writeFixture(input);
    EpsilonChopProcessor processor;
    processor.loadFile(input);
    auto state = waitForSample(processor);
    require(state.session.sample->length() == frameCount && state.session.sample->channels == 2,
            "decode stereo WAV at original length");
    require(state.session.slices.count == 8, "default eight grid chops");
    require(state.session.sample->waveform[0].high > 0.1f, "waveform peak extraction");

    processor.setMode(chop::SliceMode::transient);
    state = processor.editorState();
    const auto& analysis = *state.session.sample;
    require(analysis.transientCount >= 5, "transient slicer finds isolated attacks");
    for (std::size_t hit = 1; hit < onsets.size(); ++hit)
    {
        const auto expected = static_cast<int>(onsets[hit] * rate);
        require(std::any_of(analysis.transients.begin(), analysis.transients.begin() + analysis.transientCount,
                           [expected](int boundary) { return std::abs(boundary - expected) < 1000; }),
                "transient timing within 21 ms");
    }
    const auto firstTransient = state.session.slices.edge[1];
    processor.setMode(chop::SliceMode::manual);
    require(processor.editorState().session.slices.edge[1] == firstTransient, "manual inherits automatic markers");
    processor.editBoundary(1, firstTransient + 300);
    require(processor.editorState().session.slices.edge[1] == firstTransient + 300, "manual drag adjusts sample boundary");

    processor.setBank(1);
    const auto otherBank = processor.editorState().session.edit.patterns[0];
    processor.randomize();
    const auto randomized = processor.editorState().session.edit.patterns[1];
    processor.moveAndTrim();
    processor.undo();
    state = processor.editorState();
    require(samePattern(state.session.edit.patterns[1], randomized), "undo restores the selected pattern");
    require(samePattern(state.session.edit.patterns[0], otherBank), "bank edits remain isolated");

    const auto reference = renderNote(processor);
    juce::MemoryBlock saved;
    processor.getStateInformation(saved);
    require(input.deleteFile(), "remove source WAV before project restore");

    EpsilonChopProcessor restored;
    restored.setStateInformation(saved.getData(), static_cast<int>(saved.getSize()));
    const auto restoredState = restored.editorState();
    require(restoredState.session.sample != nullptr && restoredState.session.edit.bank == 1
            && samePattern(restoredState.session.edit.patterns[1], randomized), "restore embedded sample and banks");
    require(restoredState.session.slices.edge == state.session.slices.edge, "restore manual marker locations");
    const auto actual = renderNote(restored);
    for (int channel = 0; channel < 2; ++channel)
        require(std::equal(reference.getReadPointer(channel), reference.getReadPointer(channel) + 512,
                           actual.getReadPointer(channel)), "restored audio is sample-exact");

    restored.setStateInformation(saved.getData(), static_cast<int>(saved.getSize()) - 1);
    require(restored.editorState().session.revision == restoredState.session.revision, "truncated state is ignored");

    restored.applyPreset(1);
    checkPatternTransport(restored);
    std::cout << "WAV import, transient timing, editing, MIDI offsets, project recall and host transport passed.\n";
    if (previewPath != nullptr)
        savePreview(restored, juce::File(juce::String(previewPath)));
}
}

int main(int argc, char** argv)
{
    juce::ScopedJuceInitialiser_GUI juce;
    try
    {
        run(argc > 1 ? argv[1] : nullptr);
        return 0;
    }
    catch (const std::exception& error)
    {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
