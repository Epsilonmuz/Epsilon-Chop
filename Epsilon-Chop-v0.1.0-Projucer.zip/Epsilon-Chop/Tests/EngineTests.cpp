#include "ChopEngine.h"

#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string_view>

namespace
{
constexpr double rate = 48000.0;
constexpr double pi = 3.14159265358979323846;

void require(bool condition, std::string_view what)
{
    if (!condition)
        throw std::runtime_error(std::string(what));
}

chop::Session makeSample(int frames, double sampleRate, int density)
{
    auto sample = std::make_shared<chop::Sample>();
    sample->sampleRate = sampleRate;
    sample->channels = 1;
    sample->pcm[0].resize(static_cast<std::size_t>(frames), 0.4f);
    chop::Session session;
    session.sample = std::move(sample);
    session.sampleRevision = 1;
    session.edit = chop::defaultEdit();
    session.edit.density = density;
    session.slices = chop::makeSlices(*session.sample, session.edit);
    return session;
}

void testSlicesAndVariations()
{
    auto slices = chop::equalSlices(10003, 8);
    require(slices.count == 8 && slices.edge[4] == 5001 && slices.edge[8] == 10003, "equal slice boundaries");
    require(chop::insertBoundary(slices, 300, 90) && slices.count == 9, "insert marker");
    require(!chop::insertBoundary(slices, 325, 90), "reject overlapping markers");
    require(chop::moveBoundary(slices, 1, 9999, 90) && slices.edge[1] == slices.edge[2] - 90,
            "limit marker drag to its neighbours");
    require(chop::removeBoundary(slices, 1) && chop::validSlices(slices, 10003), "remove marker");

    const auto original = chop::makePreset(0);
    auto random = original;
    std::uint32_t seed = 1234;
    require(chop::randomizeSlices(random, 8, seed), "randomize changes a chop");
    for (int step = 0; step < chop::stepCount; ++step)
        require((original[step].slice < 0) == (random[step].slice < 0)
                 && original[step].gate == random[step].gate, "randomize preserves placement and gates");

    auto moved = original;
    require(chop::moveAndTrim(moved, seed), "move changes placement");
    std::vector<int> before, after;
    bool differentPlacement = false;
    for (int step = 0; step < chop::stepCount; ++step)
    {
        const auto a = original[step].slice;
        const auto b = moved[step].slice;
        differentPlacement = differentPlacement || (a < 0) != (b < 0);
        if (a >= 0) before.push_back(a);
        if (b >= 0)
        {
            after.push_back(b);
            require(moved[step].gate <= 75, "moved hits get short gates");
        }
    }
    require(before == after && differentPlacement, "move preserves chop order but relocates hits");
    std::cout << "Grid, manual markers and separate variation rules passed.\n";
}

std::vector<float> renderPattern(const chop::Session& session, int blockSize)
{
    chop::Engine engine;
    engine.prepare(rate);
    std::vector<float> out(24000);
    for (int offset = 0; offset < static_cast<int>(out.size()); offset += blockSize)
    {
        const auto count = std::min(blockSize, static_cast<int>(out.size()) - offset);
        engine.beginBlock(session, { offset * (2.0 / rate), 120.0, true }, true, count, 1.0f);
        for (int index = 0; index < count; ++index)
        {
            float right = 0.0f;
            engine.render(index, out[offset + index], right);
            require(out[offset + index] == right, "mono source duplicated to stereo");
        }
        engine.endBlock();
    }
    return out;
}

void testPatternTiming()
{
    auto session = makeSample(48000, rate, 1);
    session.edit.patterns[0] = {};
    session.edit.patterns[0][0] = { 0, 25 };
    session.edit.patterns[0][2] = { 0, 50 };
    const auto small = renderPattern(session, 64);
    const auto uneven = renderPattern(session, 257);
    const auto large = renderPattern(session, 1024);
    require(small == uneven && uneven == large, "pattern timing independent of block size");
    require(small[0] == 0.0f && small[100] > 0.39f, "attack fades in from silence");
    require(small[1499] == 0.0f && small[1500] == 0.0f, "25 percent gate ends at sample 1500");
    require(small[12000] == 0.0f && small[12100] > 0.39f, "step three begins at sample 12000");
    require(small[14999] == 0.0f && small[15000] == 0.0f, "50 percent gate ends at sample 15000");

    chop::Engine engine;
    engine.prepare(rate);
    engine.beginBlock(session, { 3.98, 120.0, true }, true, 128, 1.0f);
    for (int index = 0; index < 128; ++index)
    {
        float l = 0.0f, r = 0.0f;
        engine.render(index, l, r);
    }
    engine.endBlock();
    engine.beginBlock(session, { 0.0, 120.0, true }, true, 128, 1.0f);
    for (int index = 0; index < 128; ++index)
    {
        float l = 0.0f, r = 0.0f;
        engine.render(index, l, r);
        if (index == 100)
            require(l > 0.39f && engine.currentStep() == 0, "loop restarts at downbeat");
    }
    engine.endBlock();
    std::cout << "Tempo-locked gates, block sizes and loop reset passed.\n";
}

float renderResampledTone(double frequency)
{
    constexpr double sourceRate = 192000.0;
    auto session = makeSample(19200, sourceRate, 1);
    auto sample = std::make_shared<chop::Sample>(*session.sample);
    for (int index = 0; index < sample->length(); ++index)
        sample->pcm[0][index] = static_cast<float>(0.5 * std::sin(2.0 * pi * frequency * index / sourceRate));
    session.sample = sample;
    chop::Engine engine;
    engine.prepare(rate);
    engine.beginBlock(session, {}, false, 5000, 1.0f);
    engine.trigger(0, 1.0f, chop::VoiceOrigin::midi);
    double energy = 0.0;
    for (int index = 0; index < 5000; ++index)
    {
        float l = 0.0f, r = 0.0f;
        engine.render(index, l, r);
        if (index >= 300 && index < 4500)
            energy += static_cast<double>(l) * l;
        if (index >= 4800)
            require(l == 0.0f, "resampling preserves source duration");
    }
    engine.endBlock();
    return static_cast<float>(std::sqrt(energy / 4200.0));
}

void testResampling()
{
    const auto pass = renderResampledTone(2000.0);
    const auto stop = renderResampledTone(70000.0);
    require(std::abs(pass - 0.35355f) < 0.004f, "resampler passes an audible tone");
    require(stop < pass * 0.0032f, "resampler attenuates the alias probe by over 49 dB");
    std::cout << "192 to 48 kHz playback passed duration and alias rejection tests.\n";
}
}

int main()
{
    try
    {
        testSlicesAndVariations();
        testPatternTiming();
        testResampling();
        return 0;
    }
    catch (const std::exception& error)
    {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
